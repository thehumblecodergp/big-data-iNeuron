# Big Data Questions
This repo contains Python questions for BIG DATA.
